# StudentConnect – iOS Value Added Course Project

## Project idea

StudentConnect is a simple-medium iOS application that retrieves student/user information
from a JSON REST API, displays it in a UITableView, shows individual student details,
and allows selected records to be stored in a local Core Data database.

## Main modules

1. JSON API Connectivity
   - Uses URLSession.
   - Reads JSON from JSONPlaceholder.
   - Converts JSON into Swift `Student` objects using `Codable`.

2. Student List
   - Displays records using UITableView.
   - Navigation controller is used for screen navigation.

3. Student Details
   - Shows name, email, phone and website.
   - Provides a "Save to Database" button.

4. Local Database
   - Uses Apple's built-in Core Data.
   - Saves student ID, name and email.
   - Saved records can be viewed from the Saved screen.

## Technologies

- Swift
- UIKit
- URLSession
- REST API
- JSON
- Codable
- Core Data
- UITableView
- UINavigationController
- MVC-style organization

## API

The demo uses:
https://jsonplaceholder.typicode.com/users

The API is a public testing API. No login or API key is required.

## How to run

1. Open `StudentConnect.xcodeproj` in Xcode.
2. Select an iPhone simulator.
3. Press Run.
4. The app loads student records from the JSON API.
5. Tap a student to open the details page.
6. Tap "Save to Database".
7. Return and select "Saved" to view locally stored records.

## Suggested project title for submission

"StudentConnect: JSON-Based Student Information and Local Database Management System"

## Suggested viva points

- Why Codable? -> It converts JSON data into Swift objects.
- Why URLSession? -> It is Apple's standard API/networking framework.
- Why Core Data? -> It provides persistent local storage without needing an external database server.
- Why UITableView? -> It efficiently displays a list of records.
- What happens if internet is unavailable? -> The API request fails and an error alert is shown.
- Is Core Data a remote database? -> No. It is local persistent storage inside the app.

## Important

The API requires an internet connection in the simulator.
