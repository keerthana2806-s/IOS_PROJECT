import Foundation

final class StudentAPIService {

    static let shared = StudentAPIService()

    private init() {}

    func fetchStudents(completion: @escaping (Result<[Student], Error>) -> Void) {

        let urlString = "https://jsonplaceholder.typicode.com/users"

        guard let url = URL(string: urlString) else {
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }

            guard let data = data else {
                return
            }

            do {
                let students = try JSONDecoder().decode(
                    [Student].self,
                    from: data
                )

                DispatchQueue.main.async {
                    completion(.success(students))
                }

            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }

        }.resume()
    }
}
