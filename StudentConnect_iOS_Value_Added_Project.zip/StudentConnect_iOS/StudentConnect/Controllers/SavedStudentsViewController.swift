import UIKit

class SavedStudentsViewController: UIViewController {

    private let tableView = UITableView()
    private var savedStudents: [(id: Int, name: String, email: String)] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Saved Students"
        view.backgroundColor = .systemBackground

        setupTableView()
        loadSavedStudents()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadSavedStudents()
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false

        tableView.register(
            UITableViewCell.self,
            forCellReuseIdentifier: "SavedCell"
        )

        tableView.dataSource = self

        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func loadSavedStudents() {
        savedStudents = CoreDataManager.shared.fetchSavedStudents()
        tableView.reloadData()
    }
}

extension SavedStudentsViewController: UITableViewDataSource {

    func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        savedStudents.count
    }

    func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(
            withIdentifier: "SavedCell",
            for: indexPath
        )

        let student = savedStudents[indexPath.row]

        var content = cell.defaultContentConfiguration()
        content.text = student.name
        content.secondaryText = student.email
        cell.contentConfiguration = content

        return cell
    }
}
