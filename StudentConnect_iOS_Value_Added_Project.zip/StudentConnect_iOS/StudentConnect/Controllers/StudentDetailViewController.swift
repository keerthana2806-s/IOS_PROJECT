import UIKit

class StudentDetailViewController: UIViewController {

    private let student: Student

    private let nameLabel = UILabel()
    private let emailLabel = UILabel()
    private let phoneLabel = UILabel()
    private let websiteLabel = UILabel()
    private let saveButton = UIButton(type: .system)

    init(student: Student) {
        self.student = student
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Student Details"
        view.backgroundColor = .systemBackground

        setupUI()
    }

    private func setupUI() {

        nameLabel.text = student.name
        nameLabel.font = .boldSystemFont(ofSize: 28)

        emailLabel.text = "Email: \(student.email)"
        phoneLabel.text = "Phone: \(student.phone)"
        websiteLabel.text = "Website: \(student.website)"

        [emailLabel, phoneLabel, websiteLabel].forEach {
            $0.font = .systemFont(ofSize: 17)
            $0.numberOfLines = 0
        }

        saveButton.setTitle("Save to Database", for: .normal)
        saveButton.titleLabel?.font = .boldSystemFont(ofSize: 17)
        saveButton.addTarget(
            self,
            action: #selector(saveStudent),
            for: .touchUpInside
        )

        let stack = UIStackView(arrangedSubviews: [
            nameLabel,
            emailLabel,
            phoneLabel,
            websiteLabel,
            saveButton
        ])

        stack.axis = .vertical
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(
                equalTo: view.leadingAnchor,
                constant: 24
            ),
            stack.trailingAnchor.constraint(
                equalTo: view.trailingAnchor,
                constant: -24
            ),
            stack.topAnchor.constraint(
                equalTo: view.safeAreaLayoutGuide.topAnchor,
                constant: 30
            )
        ])
    }

    @objc private func saveStudent() {
        CoreDataManager.shared.saveStudent(student)

        let alert = UIAlertController(
            title: "Saved",
            message: "Student details saved to local database.",
            preferredStyle: .alert
        )

        alert.addAction(
            UIAlertAction(title: "OK", style: .default)
        )

        present(alert, animated: true)
    }
}
