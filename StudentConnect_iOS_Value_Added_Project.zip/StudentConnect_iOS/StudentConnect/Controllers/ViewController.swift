import UIKit

class ViewController: UIViewController {

    private var students: [Student] = []

    private let tableView = UITableView()
    private let activityIndicator = UIActivityIndicatorView(style: .medium)

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "StudentConnect"
        view.backgroundColor = .systemBackground

        setupNavigationBar()
        setupTableView()
        fetchStudents()
    }

    private func setupNavigationBar() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "Saved",
            style: .plain,
            target: self,
            action: #selector(showSavedStudents)
        )
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(
            UITableViewCell.self,
            forCellReuseIdentifier: "StudentCell"
        )

        tableView.dataSource = self
        tableView.delegate = self

        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func fetchStudents() {
        activityIndicator.startAnimating()

        StudentAPIService.shared.fetchStudents { [weak self] result in
            guard let self = self else { return }

            self.activityIndicator.stopAnimating()

            switch result {
            case .success(let students):
                self.students = students
                self.tableView.reloadData()

            case .failure(let error):
                self.showAlert(
                    title: "Network Error",
                    message: error.localizedDescription
                )
            }
        }
    }

    @objc private func showSavedStudents() {
        let savedVC = SavedStudentsViewController()
        navigationController?.pushViewController(savedVC, animated: true)
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(
            title: title,
            message: message,
            preferredStyle: .alert
        )

        alert.addAction(
            UIAlertAction(title: "OK", style: .default)
        )

        present(alert, animated: true)
    }
}

extension ViewController: UITableViewDataSource {

    func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        students.count
    }

    func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(
            withIdentifier: "StudentCell",
            for: indexPath
        )

        let student = students[indexPath.row]

        var content = cell.defaultContentConfiguration()
        content.text = student.name
        content.secondaryText = student.email
        cell.contentConfiguration = content

        cell.accessoryType = .disclosureIndicator

        return cell
    }
}

extension ViewController: UITableViewDelegate {

    func tableView(
        _ tableView: UITableView,
        didSelectRowAt indexPath: IndexPath
    ) {
        tableView.deselectRow(at: indexPath, animated: true)

        let student = students[indexPath.row]

        let detailVC = StudentDetailViewController(student: student)
        navigationController?.pushViewController(detailVC, animated: true)
    }
}
