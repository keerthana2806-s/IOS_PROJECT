import Foundation
import CoreData

final class CoreDataManager {

    static let shared = CoreDataManager()

    private let container: NSPersistentContainer

    private init() {
        let model = NSManagedObjectModel()

        let entity = NSEntityDescription()
        entity.name = "SavedStudent"
        entity.managedObjectClassName = "NSManagedObject"

        let idAttribute = NSAttributeDescription()
        idAttribute.name = "id"
        idAttribute.attributeType = .integer64
        idAttribute.isOptional = false

        let nameAttribute = NSAttributeDescription()
        nameAttribute.name = "name"
        nameAttribute.attributeType = .string
        nameAttribute.isOptional = false

        let emailAttribute = NSAttributeDescription()
        emailAttribute.name = "email"
        emailAttribute.attributeType = .string
        emailAttribute.isOptional = false

        entity.properties = [idAttribute, nameAttribute, emailAttribute]
        model.entities = [entity]

        container = NSPersistentContainer(
            name: "StudentConnect",
            managedObjectModel: model
        )

        container.loadPersistentStores { _, error in
            if let error = error {
                print("Core Data error: \(error)")
            }
        }
    }

    func saveStudent(_ student: Student) {
        let context = container.viewContext

        let request = NSFetchRequest<NSManagedObject>(entityName: "SavedStudent")
        request.predicate = NSPredicate(format: "id == %d", student.id)

        do {
            let existing = try context.fetch(request)

            if existing.isEmpty {
                let object = NSEntityDescription.insertNewObject(
                    forEntityName: "SavedStudent",
                    into: context
                )

                object.setValue(Int64(student.id), forKey: "id")
                object.setValue(student.name, forKey: "name")
                object.setValue(student.email, forKey: "email")

                try context.save()
            }
        } catch {
            print("Save error: \(error)")
        }
    }

    func fetchSavedStudents() -> [(id: Int, name: String, email: String)] {
        let context = container.viewContext
        let request = NSFetchRequest<NSManagedObject>(entityName: "SavedStudent")

        do {
            let objects = try context.fetch(request)

            return objects.compactMap {
                guard
                    let id = $0.value(forKey: "id") as? Int64,
                    let name = $0.value(forKey: "name") as? String,
                    let email = $0.value(forKey: "email") as? String
                else {
                    return nil
                }

                return (Int(id), name, email)
            }
        } catch {
            print("Fetch error: \(error)")
            return []
        }
    }

    func deleteAllStudents() {
        let context = container.viewContext
        let request = NSFetchRequest<NSManagedObject>(entityName: "SavedStudent")

        do {
            let objects = try context.fetch(request)
            objects.forEach { context.delete($0) }
            try context.save()
        } catch {
            print("Delete error: \(error)")
        }
    }
}
