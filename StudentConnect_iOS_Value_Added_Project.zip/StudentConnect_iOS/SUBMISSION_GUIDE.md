# Submission Guide

Project: StudentConnect

Modules demonstrated:
- ViewController
- UITableView
- JSON REST API
- URLSession
- Codable
- Core Data local database
- Navigation between screens
- MVC-style code organization

For a college demo:
1. Open StudentConnect.xcodeproj.
2. Select an iPhone simulator.
3. Run.
4. Show API-loaded student list.
5. Open a student.
6. Save it to Core Data.
7. Open Saved to demonstrate database retrieval.

Note: Internet is required for the JSON API portion.
